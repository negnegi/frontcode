/*function myFunction() {
    prompt("Please enter your name:");
}*/
/*function myFunction() {
    let text;
    let person = prompt("Please enter your name:", "Harry Potter");
    if (person == null || person == "") {
      text = "User cancelled the prompt.";
    } else {
      text = "Hello " + person + "! How are you today?";
    }
    document.getElementById("demo").innerHTML = text;
  }*/
 /* function myFunction(){
    document.getElementById('1').setAttribute('fill','#000000');
  }
*/

document.getElementById('1').addEventListener('click',function(event){
  document.getElementById('demo').innerHTML="hi";
},true)

/*document.getElementById('1').addEventListener('click', function (event) {
  document.getElementById("demo").innerHTML = "Well, a container seems better.";  

},false);
*/

