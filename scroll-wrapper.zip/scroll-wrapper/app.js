var container =document.querySelector('.scroll-container');
var content=document.querySelector('.scroll-content');
var items=document.querySelector('.scroll-item');
var isDown =false;
var startX;
var scrollLeft;

container.addEventListener('mousedown',(e)=>{
    isDown=true;
    startX=e.pageX - container.offsetLeft;
    scrollLeft=container.scrollLeft;
});
container.addEventListener('mouseleave',()=>{
    isDown=false;
});

container.addEventListener('mouseup',()=>{
    isDown=false;
});
container.addEventListener('mousemove',(e)=>{
   if(!isDown) return;
   e.preventDefault();
   const x =e.pageX - container.offsetLeft;
   const walk =(x - startX)*3;
   container.scrollLeft=scrollLeft -walk;
});






















