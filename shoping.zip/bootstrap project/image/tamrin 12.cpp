
#include"stdafx.h"
#include <iostream>
using namespace std;
void main()
{
    int n, m;
    cout<<"Enter 2 numbers: ";
    cin>>n;
    cin>>m;
    n = n + m;
    m = n - m;
    n = n - m;
    cout<<"M is: "<<m<<" "<<"N is: "<<n;
	cin.get();
	cin.ignore();
}
