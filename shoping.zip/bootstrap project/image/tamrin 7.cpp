//
//  main.cpp
//  Soale 7
//
//  Created by Pouya Kahfi on 12/3/17.
//  Copyright © 2017 Pouya Kahfi. All rights reserved.
//

#include <iostream>
using namespace std;
int main() {
    char c, c1, c2;
    int i;
    cout<<"Enter a character: ";
    while (c != '.') {
        cin>>c;
        cout<<endl;
        i = c;
        c1 = i -1;
        c2 = i +1;
        cout<<"Before: "<<c1<<endl;
        cout<<"ASCii Code: "<<i<<endl;
        cout<<"After: "<<c2<<endl;
    }
    cin.get();
    cin.ignore();
}
