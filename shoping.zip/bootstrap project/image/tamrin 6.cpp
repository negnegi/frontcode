//
//  main.cpp
//  Soale 6
//
//  Created by Pouya Kahfi on 12/3/17.
//  Copyright © 2017 Pouya Kahfi. All rights reserved.
//

#include <iostream>
#include "stdafx"
using namespace std;
int main(){
    int A[100], i, j, k, temp=0, z=0, f=0;
    cout<<"Enter a number: ";
    cin>>k;
    cout<<"Enter posetive numbers: ";
        for (i=0; i< k; i++) {
            cin>>A[i];
        }
    for (i=0; i<=k; i++) {
        temp=0;
        z=0;
        f=0;
        j = A[i];
        while (j>0) {
            temp = j%10;
            if (temp%2==0) {
                z++;
            }else {
                f++;
            }
            j = j/10;
        }
        if (f>z) {
            cout<<A[i]<<" ";
        }
    }
    cin.get();
    cin.ignore();
}
